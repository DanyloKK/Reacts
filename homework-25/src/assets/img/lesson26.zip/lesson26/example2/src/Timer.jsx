import { useEffect, useState } from "react";

const Timer = () => {
  const [date, setDate] = useState(new Date());
  const [timerId, setTimerId] = useState(null);

  useEffect(() => {
    console.log("componentDidMount");
    const timer = setInterval(() => {
      console.log("update");
      tick();
    }, 1000);

    return () => {
      if(timer !== null) {
        console.log("componentWillUnmount");
        clearInterval(timer);
      }
    };
  }, []);

  const tick = () => {
    setDate(new Date());
  };

  return (
    <div>
      Time: <p>{date.toLocaleTimeString()}</p>
      <button onClick={tick}>Update</button>
    </div>
  );
};

export default Timer;
