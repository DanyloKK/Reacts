import { useState } from 'react'
import Timer from './Timer.jsx';

const App = () => {
  const [showTime, setShowTime] = useState(true);

  const handleToggle = () => {
    setShowTime(!showTime);
  }

  return (
    <>
      {showTime ? <Timer /> : null}
      <button onClick={handleToggle}>Toggle timer</button>
    </>
  )
}

export default App
