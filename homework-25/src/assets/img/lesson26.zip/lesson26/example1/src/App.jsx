import { Component } from 'react'

class App extends Component {
  constructor (props) {
    super(props);

    this.state = {
      count: 0,
    };
    this.updateCount = this.updateCount.bind(this)
  }

  updateCount() {
    this.setState((prevState) => {
      return {
        count: prevState.count + 1
      }
    })
  }

  render() {
    return (
      <div>
      <p>Clicked {this.state.count} times</p>
      <button onClick={this.updateCount}>
        Click
      </button>
      </div>
    )
  }

}

export default App
