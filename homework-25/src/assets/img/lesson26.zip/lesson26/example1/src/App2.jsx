import { useEffect, useState } from "react";

const App2 = () => {
  const [count, setCount] = useState(0);

  const updateCount = () => {
    setCount(count + 1);
  }

  useEffect(() => {
    console.log('Component did mount');
  }, []);

  useEffect(() => {
    if(count !== 0) {
        console.log('Component did update');
    }
  }, [count]);

  return (
    <div>
      <p>Clicked {count} times</p>
      <button onClick={updateCount}>Click</button>
    </div>
  );
};

export default App2
