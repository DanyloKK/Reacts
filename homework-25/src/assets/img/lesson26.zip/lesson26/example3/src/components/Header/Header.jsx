const Header = () => {
  return (
    <header className='container'>
      <h1>Todo</h1>
    </header>
  );
};

export default Header;
